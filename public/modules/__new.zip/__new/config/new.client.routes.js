'use strict';

// Setting up route
angular.module('new').config(['$stateProvider',
  function ($stateProvider) {
    $stateProvider
      .state('app.newmodule', {
        url: '/newmodule',
        template: '<pw-new></pw-new>',
        data: {
          roles: ['user', 'admin']
        }
      });
      
  }
]);
