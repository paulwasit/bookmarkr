'use strict';

// Configuring the Chat module
angular.module('new').run(['Menus',
  function (Menus) {
    // Set top bar menu items
    Menus.addMenuItem('sidebar', {
			title: 'New', 
			state: 'app.newmodule',
			iconClass: 'fa fa-map-marker'
		});
  }
]);
