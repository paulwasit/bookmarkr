'use strict';

angular.module('new')
.directive('pwNew', [
function() {
  return {
    restrict: 'E',	
    templateUrl: 'modules/new/directives/pw-new.html',
		scope: {},
		controller: ['$scope', function($scope) {
			
		}],
		link: function(scope, element, attrs) {
			
    }
  };
}]);